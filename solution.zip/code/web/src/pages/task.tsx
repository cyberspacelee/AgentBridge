import { useEffect, useRef, useState, type FormEvent } from "react"
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom"
import {
  ArrowLeft,
  Check,
  Copy,
  Download,
  Eye,
  FileText,
  RefreshCw,
  Send,
  ShieldCheck,
  Square,
  Terminal,
  Trash2,
} from "lucide-react"
import type {
  Artifact,
  Interaction,
  InteractionReply,
  Message,
  Run,
  TaskDetail,
} from "../../../shared/contracts"
import { promptSchema } from "../../../shared/contracts"
import { useGateway } from "@/lib/gateway"
import { api, submit, useQuery } from "@/lib/api"
import {
  Blank,
  bytes,
  Choice,
  date,
  duration,
  Failure,
  IconButton,
  labels,
  number,
  Status,
} from "@/components/workspace-ui"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

export function Task() {
  const { id = "" } = useParams()
  const { revision, runtime } = useGateway()
  const [params, setParams] = useSearchParams()
  const query = useQuery<{ detail: TaskDetail }>(`/api/tasks/${id}`, revision)
  const [action, setAction] = useState<"stop" | "delete" | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<Error>()
  const navigate = useNavigate()
  const detail = query.data?.detail
  const selected =
    detail?.runs.find((r) => r.id === params.get("run")) ?? detail?.runs.at(-1)
  const tab = params.get("tab") ?? "execution"
  const change = (key: string, value: string) =>
    setParams((previous) => {
      const next = new URLSearchParams(previous)
      next.set(key, value)
      return next
    })
  async function confirm() {
    if (busy || !action) return
    setBusy(true)
    setError(undefined)
    try {
      await api(`/session/${id}${action === "stop" ? "/abort" : ""}`, {
        method: action === "stop" ? "POST" : "DELETE",
      })
      setAction(null)
      if (action === "delete") navigate("/tasks")
      else query.reload()
    } catch (e) {
      setError(e as Error)
    } finally {
      setBusy(false)
    }
  }
  return (
    <div className="page">
      <Link to="/tasks" className="back-link">
        <ArrowLeft className="size-3.5" />
        任务工作台
      </Link>
      <Failure error={query.error} />
      {query.loading && <Skeleton className="mt-4 h-72 w-full" />}
      {detail && (
        <>
          <div className="page-heading">
            <div className="min-w-0">
              <p className="eyebrow">TASK / {id.slice(0, 8)}</p>
              <h1 className="break-words">{detail.task.title}</h1>
            </div>
            <div className="flex items-center gap-2">
              <Status state={detail.task.status} />
              <IconButton label="刷新任务" onClick={query.reload}>
                <RefreshCw />
              </IconButton>
              <IconButton
                label="停止任务"
                disabled={
                  !detail.runs.some((r) =>
                    ["queued", "running", "stopping"].includes(r.state)
                  )
                }
                onClick={() => setAction("stop")}
              >
                <Square />
              </IconButton>
              <IconButton label="删除任务" onClick={() => setAction("delete")}>
                <Trash2 />
              </IconButton>
            </div>
          </div>
          <div className="task-layout">
            <div className="min-w-0">
              <div className="toolbar">
                <Choice
                  label="执行轮次"
                  value={selected?.id ?? ""}
                  options={detail.runs.map((r) => ({
                    value: r.id,
                    label: `第 ${r.sequence} 轮 · ${labels[r.state]}`,
                  }))}
                  onChange={(v) => change("run", v)}
                />
                <span className="ml-auto text-xs text-muted-foreground">
                  {selected && date(selected.acceptedAt)}
                </span>
              </div>
              <Tabs value={tab} onValueChange={(v) => change("tab", String(v))}>
                <TabsList variant="line" className="mb-3 max-w-full">
                  <TabsTrigger value="execution">执行记录</TabsTrigger>
                  <TabsTrigger value="artifacts">交付物</TabsTrigger>
                  <TabsTrigger value="interactions">交互</TabsTrigger>
                  <TabsTrigger value="diagnostics">诊断</TabsTrigger>
                </TabsList>
                <TabsContent value="execution">
                  <Execution
                    messages={detail.messages.filter(
                      (m) => m.runId === selected?.id
                    )}
                    run={selected}
                  />
                  <FollowUp
                    key={id}
                    sessionId={id}
                    disabled={
                      detail.task.availability !== "ready" ||
                      runtime?.health.status !== "ready"
                    }
                    run={selected}
                    onAccepted={(runId) => {
                      change("run", runId)
                      query.reload()
                    }}
                  />
                </TabsContent>
                <TabsContent value="artifacts">
                  <Artifacts
                    artifacts={detail.artifacts.filter(
                      (a) => a.runId === selected?.id
                    )}
                  />
                </TabsContent>
                <TabsContent value="interactions">
                  <div className="divide-y">
                    {detail.interactions
                      .filter((i) => i.runId === selected?.id)
                      .map((i) => (
                        <InteractionRow
                          key={i.id}
                          interaction={i}
                          onReply={query.reload}
                        />
                      ))}
                    {!detail.interactions.some(
                      (i) => i.runId === selected?.id
                    ) && <Blank>本轮没有交互请求</Blank>}
                  </div>
                </TabsContent>
                <TabsContent value="diagnostics">
                  {selected ? (
                    <Diagnostics run={selected} revision={revision} />
                  ) : (
                    <Blank>暂无执行记录</Blank>
                  )}
                </TabsContent>
              </Tabs>
            </div>
            <aside className="task-aside">
              <h2>任务信息</h2>
              <dl className="metadata">
                <dt>工作目录</dt>
                <dd className="font-mono">{detail.task.directory}</dd>
                <dt>引擎</dt>
                <dd>{detail.task.engineId}</dd>
                <dt>模型</dt>
                <dd>
                  {selected?.model
                    ? `${selected.model.providerID} / ${selected.model.modelID}`
                    : "引擎默认"}
                </dd>
                <dt>创建时间</dt>
                <dd>{date(detail.task.createdAt)}</dd>
                <dt>权限 / 反问</dt>
                <dd>
                  {detail.task.interactionPolicy.permission === "auto"
                    ? "自动"
                    : "人工"}{" "}
                  /{" "}
                  {detail.task.interactionPolicy.question === "auto"
                    ? "自动"
                    : "人工"}
                </dd>
                <dt>排队轮次</dt>
                <dd>{detail.task.queuedCount}</dd>
              </dl>
              {selected && (
                <>
                  <h2 className="mt-8">本轮用量</h2>
                  <dl className="metadata">
                    <dt>输入 Token</dt>
                    <dd>{number(selected.usage?.input)}</dd>
                    <dt>输出 Token</dt>
                    <dd>{number(selected.usage?.output)}</dd>
                    <dt>缓存读取 Token</dt>
                    <dd>{number(selected.usage?.cacheRead)}</dd>
                    <dt>费用 (USD)</dt>
                    <dd>{number(selected.usage?.costUsd)}</dd>
                    <dt>执行耗时</dt>
                    <dd>
                      {duration(
                        selected.startedAt && selected.finishedAt
                          ? Date.parse(selected.finishedAt) -
                              Date.parse(selected.startedAt)
                          : null
                      )}
                    </dd>
                  </dl>
                </>
              )}
            </aside>
          </div>
        </>
      )}
      <Dialog
        open={action !== null}
        onOpenChange={(open) => {
          if (!open && !busy) {
            setAction(null)
            setError(undefined)
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {action === "delete" ? "删除任务" : "停止任务"}
            </DialogTitle>
            <DialogDescription>
              {action === "delete"
                ? "删除会话、执行记录与消息。工作目录中的文件会保留。"
                : "停止当前执行并取消该任务中尚未开始的轮次。"}
            </DialogDescription>
          </DialogHeader>
          <Failure error={error} />
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => setAction(null)}
              disabled={busy}
            >
              返回
            </Button>
            <Button
              variant="destructive"
              onClick={() => void confirm()}
              disabled={busy}
            >
              {busy
                ? "正在处理"
                : action === "delete"
                  ? "确认删除"
                  : "确认停止"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function Execution({ messages, run }: { messages: Message[]; run?: Run }) {
  const [follow, setFollow] = useState(false)
  const bottom = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (follow) bottom.current?.scrollIntoView({ block: "nearest" })
  }, [messages, follow])
  return (
    <>
      <div className="flex justify-end py-2">
        <Field orientation="horizontal" className="w-auto">
          <Switch
            id="follow"
            size="sm"
            checked={follow}
            onCheckedChange={setFollow}
          />
          <FieldLabel htmlFor="follow" className="text-xs">
            跟随输出
          </FieldLabel>
        </Field>
      </div>
      <div className="execution-log">
        {messages.map((message) => (
          <article key={message.id} className="message">
            <header>
              <span
                className={
                  message.role === "assistant"
                    ? "text-emerald-700 dark:text-emerald-400"
                    : "text-muted-foreground"
                }
              >
                {message.role === "assistant" ? "Agent" : "用户"}
              </span>
              <time>{date(message.createdAt)}</time>
              <CopyText
                text={message.parts
                  .filter((p) => p.type === "text")
                  .map((p) => p.text)
                  .join("\n")}
              />
            </header>
            {message.parts.map((part) =>
              part.type === "text" ? (
                <div key={part.id} className="message-text">
                  {part.text}
                </div>
              ) : part.type === "tool" ? (
                <details key={part.id} className="tool-call">
                  <summary>
                    <Terminal className="size-3.5" />
                    <span className="min-w-0 flex-1 break-all">
                      {part.name}
                    </span>
                    <Status state={part.state} />
                  </summary>
                  <div className="tool-content">
                    <h3>输入</h3>
                    <pre>{JSON.stringify(part.input, null, 2)}</pre>
                    <h3>输出</h3>
                    <pre>{part.output || "暂无输出"}</pre>
                  </div>
                </details>
              ) : (
                <div key={part.id} className="step-finish">
                  <Check className="size-3" />
                  {part.reason === "stop" ? "本轮生成结束" : part.reason}
                </div>
              )
            )}
          </article>
        ))}
        {!messages.length && (
          <Blank>{run?.state === "queued" ? "等待执行" : "暂无消息"}</Blank>
        )}
        <div ref={bottom} />
      </div>
      {run?.error && (
        <Failure error={new Error(`${run.error.code}: ${run.error.message}`)} />
      )}
    </>
  )
}
function CopyText({ text }: { text: string }) {
  const [state, setState] = useState("复制文本")
  return (
    <IconButton
      label={state}
      disabled={!text}
      onClick={() => {
        void navigator.clipboard.writeText(text).then(
          () => setState("已复制"),
          () => setState("复制失败")
        )
      }}
    >
      {state === "已复制" ? <Check /> : <Copy />}
    </IconButton>
  )
}
function FollowUp({
  sessionId,
  disabled,
  run,
  onAccepted,
}: {
  sessionId: string
  disabled: boolean
  run?: Run
  onAccepted: (runId: string) => void
}) {
  const [text, setText] = useState("")
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<Error>()
  async function send(event: FormEvent) {
    event.preventDefault()
    if (busy || disabled) return
    setBusy(true)
    setError(undefined)
    try {
      const input = promptSchema.parse({
        parts: [{ type: "text", text }],
        ...(run?.model ? { model: run.model } : {}),
      })
      const result = await submit(input, sessionId)
      setText("")
      onAccepted(result.runId)
    } catch (e) {
      setError(e as Error)
    } finally {
      setBusy(false)
    }
  }
  return (
    <form className="follow-up" onSubmit={send}>
      <Field>
        <FieldLabel htmlFor="follow-up">追加任务</FieldLabel>
        <Textarea
          id="follow-up"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          required
          disabled={disabled || busy}
          placeholder="补充要求或继续处理文件"
        />
      </Field>
      <Failure error={error} />
      <div className="mt-3 flex justify-end gap-2">
        {run && ["failed", "timed_out", "cancelled"].includes(run.state) && (
          <Button
            variant="outline"
            disabled={disabled || busy}
            onClick={() =>
              setText(run.inputParts.map((p) => p.text).join("\n"))
            }
          >
            <RefreshCw data-icon="inline-start" />
            填入上轮要求
          </Button>
        )}
        <Button type="submit" disabled={disabled || busy || !text.trim()}>
          <Send data-icon="inline-start" />
          {busy ? "正在提交" : "提交新一轮"}
        </Button>
      </div>
    </form>
  )
}

function InteractionRow({
  interaction: i,
  onReply,
}: {
  interaction: Interaction
  onReply: () => void
}) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<Error>()
  const [answers, setAnswers] = useState<string[][]>(i.questions.map(() => []))
  async function reply(body: InteractionReply) {
    if (busy) return
    setBusy(true)
    setError(undefined)
    try {
      await api(`/${i.kind}/${i.id}/reply`, {
        method: "POST",
        body: JSON.stringify(body),
      })
      onReply()
    } catch (e) {
      setError(e as Error)
    } finally {
      setBusy(false)
    }
  }
  return (
    <section className="py-5">
      <div className="mb-3 flex items-center gap-2">
        <ShieldCheck className="size-4 shrink-0" />
        <h3 className="min-w-0 flex-1 font-medium break-words">{i.title}</h3>
        <Status state={i.state} />
      </div>
      <p className="mb-3 text-xs text-muted-foreground">
        {i.policy === "auto" ? "自动策略" : "人工处理"} · {date(i.createdAt)}
      </p>
      {i.state === "pending" && i.kind === "permission" && (
        <div className="flex flex-wrap gap-2">
          {(["once", "always", "reject"] as const).map((decision, index) => (
            <Button
              key={decision}
              variant={decision === "reject" ? "destructive" : "outline"}
              disabled={busy}
              onClick={() => void reply({ decision })}
            >
              {["允许本次", "始终允许", "拒绝"][index]}
            </Button>
          ))}
        </div>
      )}
      {i.kind === "question" && (
        <form
          onSubmit={(e) => {
            e.preventDefault()
            void reply({ answers })
          }}
        >
          <fieldset disabled={busy || i.state !== "pending"}>
            <FieldGroup>
              {i.questions.map((q, index) => (
                <Field key={index}>
                  <FieldLabel htmlFor={`${i.id}-${index}`}>{q.text}</FieldLabel>
                  {q.options.length ? (
                    <div className="flex flex-wrap gap-4">
                      {q.options.map((option) => (
                        <label
                          key={option}
                          className="flex items-center gap-2 text-sm"
                        >
                          <input
                            type={q.multiple ? "checkbox" : "radio"}
                            name={`${i.id}-${index}`}
                            checked={answers[index]?.includes(option) ?? false}
                            onChange={(e) =>
                              setAnswers((previous) =>
                                previous.map((a, n) =>
                                  n !== index
                                    ? a
                                    : q.multiple
                                      ? e.target.checked
                                        ? [...a, option]
                                        : a.filter((v) => v !== option)
                                      : [option]
                                )
                              )
                            }
                          />
                          {option}
                        </label>
                      ))}
                    </div>
                  ) : null}
                  {(q.allowCustom || !q.options.length) && (
                    <Input
                      id={`${i.id}-${index}`}
                      aria-label={`${q.text} 自定义回答`}
                      value={
                        answers[index]
                          ?.filter((a) => !q.options.includes(a))
                          .join("\n") ?? ""
                      }
                      onChange={(e) =>
                        setAnswers((previous) =>
                          previous.map((a, n) =>
                            n !== index
                              ? a
                              : e.target.value
                                ? [
                                    ...(q.multiple
                                      ? a.filter((v) => q.options.includes(v))
                                      : []),
                                    e.target.value,
                                  ]
                                : a.filter((v) => q.options.includes(v))
                          )
                        )
                      }
                    />
                  )}
                </Field>
              ))}
            </FieldGroup>
            {i.state === "pending" && (
              <Button
                className="mt-4"
                type="submit"
                disabled={busy || answers.some((a) => !a.length)}
              >
                提交回答
              </Button>
            )}
          </fieldset>
        </form>
      )}
      {i.reply && (
        <pre className="mt-3 text-xs break-words whitespace-pre-wrap text-muted-foreground">
          {JSON.stringify(i.reply, null, 2)}
        </pre>
      )}
      <Failure error={error ?? (i.error ? new Error(i.error) : undefined)} />
    </section>
  )
}

function Artifacts({ artifacts }: { artifacts: Artifact[] }) {
  const [downloadError, setDownloadError] = useState<Error>()
  const [downloading, setDownloading] = useState(false)
  async function download(artifact: Artifact) {
    if (downloading) return
    setDownloading(true)
    setDownloadError(undefined)
    try {
      const response = await fetch(`/api/artifacts/${artifact.id}/content`, {
        signal: AbortSignal.timeout(60000),
      })
      if (!response.ok) throw new Error((await response.json()).message)
      const url = URL.createObjectURL(await response.blob())
      const link = document.createElement("a")
      link.href = url
      link.download = artifact.displayName
      document.body.append(link)
      link.click()
      link.remove()
      setTimeout(() => URL.revokeObjectURL(url), 1000)
    } catch (error) {
      setDownloadError(error as Error)
    } finally {
      setDownloading(false)
    }
  }
  const [preview, setPreview] = useState<Artifact | null>(null)
  const [content, setContent] = useState<{
    id: string
    text?: string
    error?: Error
  }>()
  useEffect(() => {
    if (!preview) return
    const controller = new AbortController()
    void fetch(`/api/artifacts/${preview.id}/content?disposition=inline`, {
      signal: controller.signal,
    })
      .then(async (response) => {
        if (!response.ok) throw new Error((await response.json()).message)
        return response.text()
      })
      .then((text) => setContent({ id: preview.id, text }))
      .catch((error) => {
        if (!controller.signal.aborted) setContent({ id: preview.id, error })
      })
    return () => controller.abort()
  }, [preview])
  return (
    <>
      {artifacts.length ? (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>文件</TableHead>
              <TableHead>大小</TableHead>
              <TableHead>校验</TableHead>
              <TableHead>操作</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {artifacts.map((a) => (
              <TableRow key={a.id}>
                <TableCell className="max-w-80">
                  <div className="flex items-center gap-2">
                    <FileText className="size-4 shrink-0" />
                    <span className="break-all whitespace-normal">
                      {a.displayName}
                    </span>
                  </div>
                  <div
                    className="mt-1 truncate text-xs text-muted-foreground"
                    title={a.relativePath}
                  >
                    {a.relativePath}
                  </div>
                </TableCell>
                <TableCell>{bytes(a.sizeBytes)}</TableCell>
                <TableCell>
                  {a.validation === "not_checked"
                    ? "未校验"
                    : a.validation === "passed"
                      ? "通过"
                      : "失败"}
                </TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <IconButton
                      label={`预览 ${a.displayName}`}
                      disabled={
                        !a.mediaType.startsWith("text/") ||
                        a.sizeBytes > 1048576
                      }
                      onClick={() => setPreview(a)}
                    >
                      <Eye />
                    </IconButton>
                    <IconButton
                      label={`下载 ${a.displayName}`}
                      disabled={downloading}
                      onClick={() => void download(a)}
                    >
                      <Download className="size-4" />
                    </IconButton>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      ) : (
        <Blank>本轮暂无交付物</Blank>
      )}
      <Failure error={downloadError} />
      <Dialog
        open={!!preview}
        onOpenChange={(open) => {
          if (!open) setPreview(null)
        }}
      >
        <DialogContent className="max-h-[90svh] overflow-y-auto sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle className="pr-6 break-all">
              {preview?.displayName}
            </DialogTitle>
          </DialogHeader>
          {content?.id === preview?.id ? (
            <>
              <Failure error={content?.error} />
              <pre className="max-h-[65svh] overflow-auto text-xs break-words whitespace-pre-wrap">
                {content?.text}
              </pre>
            </>
          ) : (
            <Skeleton className="h-64" />
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}

function Diagnostics({ run, revision }: { run: Run; revision: number }) {
  const query = useQuery<{
    spans: {
      name: string
      startedAt: string | null
      finishedAt: string | null
      state?: string
    }[]
    logs: { id: number; occurredAt: string; code: string; message: string }[]
  }>(`/api/observability/runs/${run.id}`, revision)
  return (
    <div className="space-y-6">
      <dl className="diagnostic-ids">
        <dt>Run ID</dt>
        <dd>
          {run.id}
          <CopyText text={run.id} />
        </dd>
        <dt>Trace ID</dt>
        <dd>
          {run.traceId}
          <CopyText text={run.traceId} />
        </dd>
      </dl>
      <Failure error={query.error} />
      <h3 className="font-medium">执行阶段</h3>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>阶段</TableHead>
            <TableHead>开始</TableHead>
            <TableHead>耗时</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {query.data?.spans.map((span, index) => (
            <TableRow key={index}>
              <TableCell className="max-w-64 truncate">{span.name}</TableCell>
              <TableCell>{date(span.startedAt)}</TableCell>
              <TableCell>
                {duration(
                  span.startedAt && span.finishedAt
                    ? Date.parse(span.finishedAt) - Date.parse(span.startedAt)
                    : null
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <h3 className="font-medium">错误日志</h3>
      {query.data?.logs.length ? (
        query.data.logs.map((log) => (
          <div key={log.id} className="border-b py-3">
            <div className="mb-1 text-xs text-muted-foreground">
              {date(log.occurredAt)} · {log.code}
            </div>
            <p className="break-words">{log.message}</p>
          </div>
        ))
      ) : (
        <Blank>本轮暂无错误日志</Blank>
      )}
    </div>
  )
}
