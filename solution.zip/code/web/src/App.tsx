import { lazy, Suspense } from "react"
import {
  BrowserRouter,
  Navigate,
  NavLink,
  Route,
  Routes,
} from "react-router-dom"
import { Activity, ListTodo, Network, RefreshCw, Moon, Sun } from "lucide-react"
import type { RuntimeInfo } from "../../shared/contracts"
import { TooltipProvider } from "@/components/ui/tooltip"
import { Failure, IconButton, Status } from "@/components/workspace-ui"
import { useEvents, useQuery } from "@/lib/api"
import { GatewayContext } from "@/lib/gateway"
import { Tasks } from "@/pages/tasks"
import { useTheme } from "@/components/theme-provider"
import { Skeleton } from "@/components/ui/skeleton"
const Observability = lazy(() =>
  import("@/pages/observability").then((module) => ({
    default: module.Observability,
  }))
)
const Task = lazy(() =>
  import("@/pages/task").then((module) => ({ default: module.Task }))
)

export default function App() {
  const events = useEvents()
  const { theme, setTheme } = useTheme()
  const runtime = useQuery<RuntimeInfo>("/api/runtime", events.revision)
  return (
    <BrowserRouter>
      <TooltipProvider delay={250}>
        <GatewayContext
          value={{ runtime: runtime.data, revision: events.revision }}
        >
          <div className="app-shell">
            <header className="app-header">
              <NavLink to="/tasks" className="brand">
                <Network className="size-5 text-emerald-700" />
                <span>AgentBridge</span>
              </NavLink>
              <nav aria-label="主导航">
                <NavLink to="/tasks">
                  <ListTodo />
                  任务工作台
                </NavLink>
                <NavLink to="/observability">
                  <Activity />
                  网关观测
                </NavLink>
              </nav>
              <div className="header-runtime">
                <span className="font-mono text-xs">
                  {runtime.data?.engine ?? "Gateway"}
                </span>
                {runtime.data && <Status state={runtime.data.health.status} />}
                <IconButton
                  label={theme === "dark" ? "切换浅色" : "切换深色"}
                  onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                >
                  {theme === "dark" ? <Sun /> : <Moon />}
                </IconButton>
                <IconButton label="刷新网关状态" onClick={runtime.reload}>
                  <RefreshCw />
                </IconButton>
              </div>
            </header>
            {runtime.error && (
              <div className="px-5 pt-3">
                <Failure error={runtime.error} />
              </div>
            )}
            <main id="main-content">
              <Suspense
                fallback={
                  <div className="page">
                    <Skeleton className="h-72" />
                  </div>
                }
              >
                <Routes>
                  <Route path="/tasks" element={<Tasks />} />
                  <Route path="/tasks/:id" element={<Task />} />
                  <Route path="/observability" element={<Observability />} />
                  <Route path="/" element={<Navigate to="/tasks" replace />} />
                  <Route
                    path="*"
                    element={
                      <div className="page">
                        <h1>页面不存在</h1>
                        <NavLink to="/tasks">返回任务工作台</NavLink>
                      </div>
                    }
                  />
                </Routes>
              </Suspense>
            </main>
            <footer className="app-footer">
              <span className={`connection connection-${events.state}`}>
                {events.state === "live"
                  ? "事件流已连接"
                  : events.state === "reconnecting"
                    ? "事件流重连中"
                    : "正在连接"}
              </span>
              <span>
                {runtime.data?.storage.toUpperCase() ?? "Gateway"}
                <span className="hidden sm:inline">
                  {" "}
                  · {runtime.data?.instanceId.slice(0, 8) ?? "连接中"}
                </span>
              </span>
            </footer>
          </div>
        </GatewayContext>
      </TooltipProvider>
    </BrowserRouter>
  )
}
