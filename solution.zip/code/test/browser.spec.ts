import { test, expect } from "@playwright/test";

test("task assignment, approval, output, observations, cancellation and deletion", async ({
  page,
  request,
}, info) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  const { directory } = await (await request.get("/__test/directory")).json();
  await page.goto("/tasks");
  await expect(
    page.getByRole("button", { name: "分派任务", exact: true }),
  ).toBeEnabled();
  await page.getByRole("button", { name: "分派任务", exact: true }).click();
  const dialog = page.getByRole("dialog");
  await dialog
    .getByLabel("任务名称", { exact: true })
    .fill(`销售分析-${info.project.name}`);
  await dialog.getByLabel("工作目录", { exact: true }).fill(directory);
  await dialog
    .getByLabel("任务要求", { exact: true })
    .fill("汇总销售数据并生成报告");
  await dialog.getByRole("switch", { name: "人工审批权限" }).check();
  await dialog.getByRole("button", { name: "分派任务", exact: true }).click();
  await expect(page).toHaveURL(/\/tasks\/[\w-]+/);
  await page.getByRole("tab", { name: "交互", exact: true }).click();
  await page.getByRole("button", { name: "允许本次", exact: true }).click();
  await page.getByRole("tab", { name: "执行记录" }).click();
  await expect(
    page.getByText("销售分析已完成，结果已写入 report.md。"),
  ).toBeVisible();
  await page.getByText("write", { exact: true }).click();
  await expect(page.getByText("Wrote report.md")).toBeVisible();
  await page.screenshot({ path: info.outputPath("task.png"), fullPage: true });
  await page.getByRole("tab", { name: "交付物" }).click();
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "下载 report.md" }).click();
  expect((await download).suggestedFilename()).toBe("report.md");
  await page.getByRole("button", { name: "预览 report.md" }).click();
  await expect(page.getByRole("dialog").getByText(/Total: 42/)).toBeVisible();
  await page.keyboard.press("Escape");
  await page.getByRole("tab", { name: "诊断" }).click();
  await expect(page.getByText("Trace ID", { exact: true })).toBeVisible();
  await page.getByRole("link", { name: "网关观测", exact: true }).click();
  await expect(page.getByText("P95 执行耗时", { exact: true })).toBeVisible();
  await page.screenshot({
    path: info.outputPath("observability.png"),
    fullPage: true,
  });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth > innerWidth,
    ),
  ).toBe(false);
  await page.getByRole("button", { name: "切换深色", exact: true }).click();
  await expect(page.locator("html")).toHaveClass(/dark/);
  await page.screenshot({
    path: info.outputPath("observability-dark.png"),
    fullPage: true,
  });
  await page.getByRole("button", { name: "切换浅色", exact: true }).click();
  await page.getByRole("tab", { name: "工具与用量" }).click();
  await expect(
    page.getByRole("cell", { name: "write", exact: true }),
  ).toBeVisible();
  await page.getByRole("tab", { name: "引擎与资源" }).click();
  await expect(page.getByText("网关 RSS", { exact: true })).toBeVisible();
  await page.getByRole("tab", { name: "错误", exact: true }).click();
  await page.getByRole("link", { name: "任务工作台", exact: true }).click();
  await page
    .getByRole("link", { name: `销售分析-${info.project.name}`, exact: true })
    .click();
  await page.getByLabel("追加任务", { exact: true }).fill("hold");
  await page.getByRole("button", { name: "提交新一轮" }).click();
  await expect(
    page.getByRole("button", { name: "停止任务", exact: true }),
  ).toBeEnabled();
  await page.getByRole("button", { name: "停止任务", exact: true }).click();
  await page.getByRole("button", { name: "确认停止" }).click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await page.getByRole("button", { name: "删除任务", exact: true }).click();
  await page.getByRole("button", { name: "确认删除" }).click();
  await expect(page).toHaveURL(/\/tasks$/);
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > innerWidth,
  );
  expect(overflow).toBe(false);
  expect(errors).toEqual([]);
});
